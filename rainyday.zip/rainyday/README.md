# rainyday
xfce window decoration


Copy the rainyday folder to your /home/<user>/.themes folder 
or to /user/share/themes folder for system wide accessibility
